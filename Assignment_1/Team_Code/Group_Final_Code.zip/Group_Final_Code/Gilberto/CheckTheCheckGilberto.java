/*
   Gilberto Lopez 
   10/03/2014
   Assignment 2: Chech The Check 
*/

import java.util.*;
import java.io.*;

public class CheckTheCheckGilberto
{
	static FileReader file = new FileReader();
	
	public static void main(String[] args) 
	{			
      file.readFile(args[0]);
	}
}
